To use this style in Fluxbox, copy the Windows 10 folder to ~/.fluxbox.styles 

To have Fluxbox refresh the cache, open the Fluxbox menu and press "Reconfigure"

Then, on your fluxbox menu, choose Styles > Windows 10 and restart your session.
